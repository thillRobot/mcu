from btcommon import *

raise NotImplementedError
