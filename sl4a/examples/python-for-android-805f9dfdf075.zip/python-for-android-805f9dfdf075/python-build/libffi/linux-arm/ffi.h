/*
 * Copyright 2008 The Android Open Source Project
 */
#ifndef LIBFFI_H

#define ARM
#include "../src/arm/ffitarget.h"
#include "../include/ffi_real.h"

#endif
