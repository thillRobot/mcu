adb push _install/bin/python3 /data/data/robbie/bin
adb shell /data/data/robbie/standalone.sh -v
