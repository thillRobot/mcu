export PATH=/home/robbie/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/home/robbie/android-toolchain/bin:~/android-sdk-linux_86/platform-tools
