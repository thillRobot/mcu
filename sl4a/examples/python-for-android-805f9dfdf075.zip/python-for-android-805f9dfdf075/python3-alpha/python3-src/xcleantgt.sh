adb shell rm -r /data/data/com.googlecode.python3forandroid
adb shell rm -r /sdcard/com.googlecode.python3forandroid
