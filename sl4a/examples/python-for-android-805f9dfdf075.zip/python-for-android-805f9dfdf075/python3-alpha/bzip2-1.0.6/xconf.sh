TARGET=arm-linux-androideabi
./configure --host=$TARGET --target=$TARGET --prefix=$PWD/compiled/$TARGET
