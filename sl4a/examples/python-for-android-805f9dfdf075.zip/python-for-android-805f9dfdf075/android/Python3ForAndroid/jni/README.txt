To build, run the following command from the PythonForAndroid root dir (one 
level above the directory containing this file):

ndk-build && cp jni/libpython2.6.so libs/armeabi

Then build the project as normal in Eclipse.