Folders for Sample Configs should include
<Type of Gimbal>_<Type of Camera>

Files should include BruGi Version

All config is assumed to be @12Volt unless otherwise noted