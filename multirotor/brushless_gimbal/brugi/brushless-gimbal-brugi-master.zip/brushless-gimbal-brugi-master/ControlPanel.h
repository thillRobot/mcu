#ifndef _CONTROLPANEL_H_
#define _CONTROLPANEL_H_


enum pbState_t {
  PB_IDLE=0, 
  PB_ENTER_IN,
  PB_ENTER_WAIT,
  PB_ENTER_PRESSED,
  PB_IDLE_IN
};

#endif /*  _CONTROLPANEL_H_ */
