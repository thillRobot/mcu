
/* prototypes for Timer1 based timing functions */

unsigned long millisT1();
unsigned long microsT1();
void delayT1(unsigned long ms);

